import os
import connexion
import spacy
from flask import jsonify
import re
from transformers import pipeline, BertForTokenClassification, BertTokenizer
from transformers import BartForConditionalGeneration, BartTokenizer
from typing import List
from medcat.cat import CAT
from medcat.utils.vocab import Vocab
from medcat.cdb import CDB 

MODELS = os.getenv('MODELS', '/models')

VOCAB_DAT = os.path.join(MODELS,"medcat","vocab.dat")
CDB_DAT = os.path.join(MODELS,"medcat","cdb-medmen.dat")

vocab = Vocab()
# Load the vocab model you downloaded
vocab.load_dict(VOCAB_DAT)      

# Load the cdb model you downloaded
cdb = CDB()
cdb.load_dict(CDB_DAT) 

# create cat
cat = CAT(cdb=cdb, vocab=vocab)

cli_ner_pipeline = pipeline('ner', model=BertForTokenClassification.from_pretrained(os.path.join(MODELS, "cli_ner")),
                           tokenizer=BertTokenizer(vocab_file=os.path.join(MODELS, "cli_ner", 'vocab.txt'),
                                                   do_lower_case=False), ignore_labels = [])

drugs_ner_pipeline = pipeline('ner', model=BertForTokenClassification.from_pretrained(os.path.join(MODELS, "drugs_ner")),
                            tokenizer=BertTokenizer(vocab_file=os.path.join(MODELS, "drugs_ner", 'vocab.txt'),
                                                    do_lower_case=False), ignore_labels = [])

summarizer_pipeline = pipeline("summarization", model=os.path.join(MODELS, "summarizer"),
                             tokenizer=os.path.join(MODELS, "summarizer"))

supported_services = {"cli_ner": cli_ner_pipeline,
                     "summarization": summarizer_pipeline,
                     "drugs_ner": drugs_ner_pipeline
                     }
nlp = spacy.load("en_core_web_sm")
nlp.add_pipe(nlp.create_pipe('sentencizer'))

def get_umls_concepts(annotations):

    batch = []
    for annotation in annotations:
        batch.append((1,annotation['word']))

    results = cat.multi_processing(batch)
    
    for i in range(len(results)):
        (id,entities) = results[i]
        if len(entities['entities']) > 0:
            cui = entities['entities'][0]
            if annotations[i]['entity'] == 'B-TREATMENT' or annotations[i]['entity'] == 'B-TEST' or annotations[i]['entity'] == 'B-PROBLEM':
                annotations[i]['cui'] = cui['cui']
    return annotations


def process_subword_tokens(annotations):
    prev_ann = None
    new_list = []
    for ann in annotations:
        if ann['word'] != '[CLS]' and ann['word'] != '[SEP]':
            if ann['word'].startswith('##'):
                prev_ann['word'] += ann['word'].replace('##','')
            elif ann['entity'].startswith("I-"):
                prev_ann['word'] += ' ' + ann['word']
            else:
                prev_ann = ann
                new_list.append(ann)
    
    new_list = get_umls_concepts(new_list)
    return new_list

def get_services():
    response = {
        'services': list(supported_services.keys())
    }
    return jsonify(response), 200

phone_number_regex = re.compile(r'''(
    [(]?(\d{3})?[)]? # area code
    (\s|-|\.)? # separator
    (\d{3}) # first 3 digits
    (\s|-|\.) # separator
    (\d{4}) # last 4 digits
    (\s|,)? # separator
    (\s*(ext|x|ext.)\s*(\d{2,5}))? # extension
 )''', re.VERBOSE | re.IGNORECASE)

address_regex = re.compile(r"\b(\d{2,5})\b\s+([a-zA-Z|\s+]{1,5})\s+(court|ct|street|st|drive|dr|lane|trl|ln|road|rd|blvd)\b",re.IGNORECASE)
zipcode_regex = re.compile(r"\b(\d{5})\b")

def extract_address_phone(body):
    text = body['text']

    doc = nlp(text,disable=["tagger", "parser"])

    phone_spans = []
    add_spans = []
    for match in re.finditer(address_regex,text):
        start, end = match.span()
        add_spans.append((start,end))
    for match in re.finditer(phone_number_regex,text):
        start, end = match.span()
        phone_spans.append((start,end))

    resp = []

    for token in doc:
        token_ann = {}
        token_ann['entity'] = 'O'
        token_ann['word'] = token.text

        for (start,end) in phone_spans:
            if token.idx == start:
                token_ann['entity'] = 'B-PHONE'
            elif token.idx > start and token.idx < end:
                token_ann['entity'] = 'I-PHONE'    

        for (start,end) in add_spans:
            if token.idx == start:
                token_ann['entity'] = 'B-ADDRESS'
            elif token.idx > start and token.idx < end:
                token_ann['entity'] = 'I-ADDRESS'  

        resp.append(token_ann)

    resp = process_subword_tokens(resp)

    response = {
        'output' : resp
    }
    return jsonify(response), 200


def process_text(service_name, body):
    if service_name in supported_services:
        try:
            resp = []
            if service_name != 'summarization':
                doc = nlp(body['text'],disable=["tagger", "parser"])
                for sent in doc.sents:
                    anns = supported_services[service_name](sent.text)
                    resp.extend(anns)
            
                resp = process_subword_tokens(resp)
            
            else:
                text = body['text']
                text = ' '.join(text.split(' ')[:1024])
                resp = summarizer_pipeline(text)

            response = {
                'output': resp,
            }   
            code = 200
        except Exception as e:
            print(e)
            response = {
                'type': 'Processing Error',
                'message': 'Problem processing text'
            }
            code = 404
    else:
        response = {
            'type': 'Service not supported',
            'message': 'Service not supported'
        }
        code = 404

    return jsonify(response), code


APP = connexion.App(__name__, specification_dir='config/')
APP.add_api('swagger.yaml', base_path=os.getenv('BASE_PATH', '/transformers'))
